﻿global using System.Net.Http;
global using SolutionSample.Client;
global using Microsoft.AspNetCore.Components.Web;
global using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
global using Shared.Models;