﻿global using Grpc.Core;
global using SolutionSample.Server.Services;