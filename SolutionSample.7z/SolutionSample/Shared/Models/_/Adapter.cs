﻿namespace Shared.Models
{
    public class Adapter
    {
        public string ResCode { get; set; } = string.Empty;
        public string ResMsg { get; set; } = string.Empty;
    }
}
