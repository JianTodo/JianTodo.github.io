// <copyright file="UnitTest1.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace SolutionSample.PerformanceTest;

/// <summary>
/// Tests.
/// </summary>
public class Tests
{
    /// <summary>
    /// Setup.
    /// </summary>
    [SetUp]
    public void Setup()
    {
    }

    /// <summary>
    /// Test1.
    /// </summary>
    [Test]
    public void Test1()
    {
        Assert.Pass();
    }
}