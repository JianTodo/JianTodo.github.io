﻿namespace SolutionSample.Service
{
    public class WeatherForecastFacadeService : IWeatherForecastFacade
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        public Task<List<WeatherForecast>> GetForecastAsync(CancellationToken cancellationToken = default)
        {
            return Task.FromResult(Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Today.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            }).ToList());
        }

        public Task<Adapter<List<WeatherForecast>>> GetForecastsAsync(CancellationToken cancellationToken = default)
        {
            var result =
                new Adapter<List<WeatherForecast>>()
                {
                    Model = Enumerable.Range(1, 5).Select(index => new WeatherForecast
                    {
                        Date = DateTime.Today.AddDays(index),
                        TemperatureC = Random.Shared.Next(-20, 55),
                        Summary = Summaries[Random.Shared.Next(Summaries.Length)]
                    }).ToList(),
                    ResCode = "000000000"
                };
            return Task.FromResult(result);
        }
    }
}
