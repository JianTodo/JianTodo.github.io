﻿// <copyright file="WeatherForecastFacadeService.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace SolutionSample.Service;

/// <summary>
/// Weather Forecast Facade (Service).
/// </summary>
public class WeatherForecastFacadeService : IWeatherForecastFacade
{
    /// <summary>
    /// Get Forecasts Async.
    /// </summary>
    /// <param name="summaryExt">Test Inputer.</param>
    /// <returns>Adapter&lt;List&lt;WeatherForecast&gt;&gt;.</returns>
    public Task<Adapter<List<WeatherForecast>>> GetForecastsAsync(WeatherSummaryExt summaryExt)
    {
        summaryExt.Value.AddRange(new[]
        {
            "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching",
        });

        var result =
            new Adapter<List<WeatherForecast>>()
            {
                Model = Enumerable.Range(1, 5).Select(index => new WeatherForecast
                {
                    Date = DateTime.Today.AddDays(index),
                    TemperatureC = Random.Shared.Next(-20, 55),
                    Summary = summaryExt.Value[Random.Shared.Next(summaryExt.Value.Count)],
                }).ToList(),
                ResCode = ResCode.Success,
            };
        return Task.FromResult(result);
    }
}
