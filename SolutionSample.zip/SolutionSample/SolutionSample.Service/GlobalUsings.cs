global using Shared.Interfaces;
global using Shared.Models;

