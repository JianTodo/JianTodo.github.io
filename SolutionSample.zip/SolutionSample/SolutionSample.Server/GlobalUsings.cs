﻿// <copyright file="GlobalUsings.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

global using System.IO.Compression;
global using Grpc.Core;
global using ProtoBuf.Grpc.Server;
global using SolutionSample.Service;