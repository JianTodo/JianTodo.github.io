﻿global using System.IO.Compression;
global using Grpc.Core;
global using ProtoBuf.Grpc.Server;
global using SolutionSample.Service;