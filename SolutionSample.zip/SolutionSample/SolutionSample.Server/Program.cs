// <copyright file="Program.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

var builder = WebApplication.CreateBuilder(args);

// Grpc
builder.Services.AddGrpc();
builder.Services.AddCodeFirstGrpc(config => { config.ResponseCompressionLevel = CompressionLevel.Optimal; });

// Cors Origins
const string corsPolicy = "CorsAll";
builder.Services.AddCors(options =>
{
    options.AddPolicy(
        name: corsPolicy,
        policy =>
        {
            policy.WithOrigins("*")
                  .AllowAnyHeader()
                  .AllowAnyMethod();
        });
});

var app = builder.Build();

app.UseCors(corsPolicy);

// Grpc Web
app.UseGrpcWeb(new GrpcWebOptions() { DefaultEnabled = true });

// Grpc Endpoint
app.MapGrpcService<WeatherForecastFacadeService>();

app.Run();

/// <summary> Top Code. </summary>
public partial class Program
{
}