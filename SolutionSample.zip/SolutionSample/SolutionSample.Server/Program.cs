var builder = WebApplication.CreateBuilder(args);

builder.Services.AddGrpc();
builder.Services.AddCodeFirstGrpc(config => { config.ResponseCompressionLevel = CompressionLevel.Optimal; });
const string corsPolicy = "CorsAll";
builder.Services.AddCors(options =>
{
    options.AddPolicy(name: corsPolicy,
                      policy =>
                      {
                          policy.WithOrigins("*")
                                .AllowAnyHeader()
                                .AllowAnyMethod();
                      });
});
var app = builder.Build();
app.UseGrpcWeb(new GrpcWebOptions() { DefaultEnabled = true });
app.UseCors(corsPolicy);
app.MapGrpcService<WeatherForecastFacadeService>();
//app.MapGrpcService<GreeterService>();
//app.MapGet("/", () => "");
app.Run();