﻿// <copyright file="GlobalUsings.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>
global using System;
global using System.Collections.Generic;
global using System.Runtime.Serialization;
global using System.ServiceModel;
global using System.Text.Json;
global using System.Threading.Tasks;
global using Shared.Interfaces;
global using Shared.Models;