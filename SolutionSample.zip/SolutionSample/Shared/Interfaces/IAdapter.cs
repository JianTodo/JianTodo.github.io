﻿// <copyright file="IAdapter.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Interfaces;

/// <summary>
/// Return Base Model (Interface).
/// </summary>
internal interface IAdapter
{
    /// <summary>
    /// Gets or sets Result Code.
    /// </summary>
    internal string ResCode { get; set; }

    /// <summary>
    /// Gets or sets Result Message.
    /// </summary>
    internal string ResMsg { get; set; }
}
