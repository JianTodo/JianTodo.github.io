﻿// <copyright file="IWeatherForecastFacade.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Interfaces;

/// <summary>
/// Weather Forecast Facade (Interface).
/// </summary>
[ServiceContract]
public interface IWeatherForecastFacade
{
    /// <summary>
    /// Get Forecasts Async.
    /// </summary>
    /// <param name="summaryExt">Test Inputer.</param>
    /// <returns>Adapter&lt;List&lt;WeatherForecast&gt;&gt;.</returns>
    Task<Adapter<List<WeatherForecast>>> GetForecastsAsync(WeatherSummaryExt summaryExt);
}
