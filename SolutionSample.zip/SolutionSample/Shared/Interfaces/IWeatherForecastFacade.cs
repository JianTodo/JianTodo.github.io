﻿namespace Shared.Interfaces
{
    [ServiceContract]
    public interface IWeatherForecastFacade
    {
        Task<List<WeatherForecast>> GetForecastAsync(CancellationToken cancellationToken = default);

        Task<Adapter<List<WeatherForecast>>> GetForecastsAsync(CancellationToken cancellationToken = default);
    }
}
