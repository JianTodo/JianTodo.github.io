﻿// <copyright file="WeatherSummaryExt.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Models;

/// <summary>
/// WeatherSummaryExt.
/// </summary>
[DataContract]
public class WeatherSummaryExt
{
    /// <summary>
    /// Gets or sets Value.
    /// </summary>
    [DataMember(Order = 1)]
    public List<string> Value { get; set; } = new List<string>();
}
