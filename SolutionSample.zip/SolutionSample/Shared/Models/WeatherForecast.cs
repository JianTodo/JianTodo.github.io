﻿// <copyright file="WeatherForecast.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Models;

/// <summary>
/// WeatherForecast.
/// </summary>
[DataContract]
public class WeatherForecast
{
    /// <summary>
    /// Gets or sets Date.
    /// </summary>
    [DataMember(Order = 1)]
    public DateTime Date { get; set; }

    /// <summary>
    /// Gets or sets Date.
    /// </summary>
    [DataMember(Order = 2)]
    public int TemperatureC { get; set; }

    /// <summary>
    /// Gets or sets Date.
    /// </summary>
    [DataMember(Order = 3)]
    public string? Summary { get; set; }

    /// <summary>
    /// Gets TemperatureF.
    /// </summary>
    public int TemperatureF => 32 + (int)(this.TemperatureC / 0.5556);
}
