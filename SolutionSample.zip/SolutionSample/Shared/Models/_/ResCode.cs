﻿// <copyright file="ResCode.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Models;

/// <summary>
/// Status Code.
/// </summary>
public static class ResCode
{
    /// <summary>
    /// Gets Success.
    /// </summary>
    /// <value>000000000.</value>
    public static string Success { get; private set; } = "000000000";

    /// <summary>
    /// Gets Failure(Include Exception).
    /// </summary>
    /// <value>999999999.</value>
    public static string Failure { get; private set; } = "999999999";
}
