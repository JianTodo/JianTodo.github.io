﻿// <copyright file="Config.Connection.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Models;

/// <summary>
/// Connection.
/// </summary>
public class Connection
{
    /// <summary>
    /// Gets or sets each end point.
    /// </summary>
    public Endpoint EndPoints { get; set; } = new Endpoint();
}
