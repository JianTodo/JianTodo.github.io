﻿// <copyright file="Config.Endpoint.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Models;

/// <summary>
/// Endpoint.
/// </summary>
public class Endpoint
{
    /// <summary>
    /// Gets or sets main Server.
    /// </summary>
    public string MainServer { get; set; } = string.Empty;
}
