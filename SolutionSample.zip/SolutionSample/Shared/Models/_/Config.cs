﻿// <copyright file="Config.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>
namespace Shared.Models;

/// <summary>
/// configuration.
/// </summary>
public class Config
{
    /// <summary>
    /// Gets or sets connection.
    /// </summary>
    public Connection Connection { get; set; } = new Connection();
}