﻿// <copyright file="Adapter.Generic.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Models;

/// <summary>
/// Return Base Model.
/// </summary>
/// <typeparam name="T">Any Object.</typeparam>
[DataContract]
public class Adapter<T> : IAdapter
{
    /// <summary>
    /// Gets or sets retrun Result Code.
    /// </summary>
    /// <see cref="Models.ResCode"/>
    [DataMember(Order = 1)]
    public string ResCode { get; set; } = Models.ResCode.Success;

    /// <summary>
    /// Gets or sets Retrun Result Message.
    /// </summary>
    [DataMember(Order = 2)]
    public string ResMsg { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets Any Object.
    /// </summary>
    [DataMember(Order = 3)]
    public T? Model { get; set; } = default;
}
