﻿// <copyright file="Adapter.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Models;

/// <summary>
/// Return Base Model.
/// </summary>
[DataContract]
public class Adapter : IAdapter
{
    /// <summary>
    /// Gets or sets Retrun Result Code.
    /// </summary>
    /// <see cref="Models.ResCode"/>
    [DataMember(Order = 1)]
    public string ResCode { get; set; } = Models.ResCode.Success;

    /// <summary>
    /// Gets or sets retrun Result Message.
    /// </summary>
    [DataMember(Order = 2)]
    public string ResMsg { get; set; } = string.Empty;
}
