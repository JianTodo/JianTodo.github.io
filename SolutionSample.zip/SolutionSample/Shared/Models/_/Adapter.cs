﻿namespace Shared.Models
{
    [DataContract]
    public class Adapter
    {
        [DataMember(Order = 1)]
        public string ResCode { get; set; } = string.Empty;

        [DataMember(Order = 2)]
        public string ResMsg { get; set; } = string.Empty;
    }

    [DataContract]
    public class Adapter<T>
    {
        [DataMember(Order = 1)]
        public string ResCode { get; set; } = string.Empty;

        [DataMember(Order = 2)]
        public string ResMsg { get; set; } = string.Empty;

        [DataMember(Order = 3)]
        public T? Model { get; set; }
    }
}
