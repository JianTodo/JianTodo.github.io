﻿// <copyright file="JsonExtension.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

namespace Shared.Extensions;

/// <summary>
/// Json Extension.
/// </summary>
public static class JsonExtension
{
    /// <summary>
    /// String Convert Object.
    /// </summary>
    /// <typeparam name="T">Generic.</typeparam>
    /// <param name="obj">Object (string).</param>
    /// <returns>Object.</returns>
    public static T AsParse<T>(this string obj)
        where T : new()
    {
        T? result = default(T);
        try
        {
            result = JsonSerializer.Deserialize<T>(obj)!;
        }
        finally
        {
            result = result ?? new T();
        }

        return result!;
    }
}
