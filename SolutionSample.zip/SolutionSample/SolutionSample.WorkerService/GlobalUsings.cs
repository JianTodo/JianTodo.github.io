// <copyright file="GlobalUsings.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

global using SolutionSample.WorkerService;
global using SolutionSample.WorkerService.Works;