global using SolutionSample.WorkerService;
global using SolutionSample.WorkerService.Works;
// global using SolutionSample.Service;