﻿// <copyright file="GlobalUsings.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
