// <copyright file="GlobalUsings.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

global using NUnit.Framework;