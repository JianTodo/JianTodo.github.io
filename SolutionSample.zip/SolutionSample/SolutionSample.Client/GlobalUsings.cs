﻿// <copyright file="GlobalUsings.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

global using System.Net.Http;
global using Grpc.Net.Client.Web;
global using Microsoft.AspNetCore.Components.Web;
global using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
global using ProtoBuf.Grpc.ClientFactory;
global using Shared.Extensions;
global using Shared.Interfaces;
global using Shared.Models;
global using SolutionSample.Client;