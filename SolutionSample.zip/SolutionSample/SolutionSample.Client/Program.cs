// <copyright file="Program.cs" company="IBM Corp">
// Copyright (c) IBM Corp. All rights reserved.
// </copyright>

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

var http = new HttpClient()
{
    BaseAddress = new Uri(builder.HostEnvironment.BaseAddress),
};

builder.Services.AddScoped(sp => http);

using var response = await http.GetAsync("appsettings.json");
using var stream = await response.Content.ReadAsStreamAsync();
builder.Configuration.AddJsonStream(stream);

builder.Services.AddSingleton<Config>((await response.Content.ReadAsStringAsync()).AsParse<Config>());
builder.Services.AddTransient<GrpcWebHandler>((provider) => new GrpcWebHandler(GrpcWebMode.GrpcWeb, new HttpClientHandler()));
builder.Services.AddCodeFirstGrpcClient<IWeatherForecastFacade>((provider, options) =>
{
    /* Hosting Mode
    //var navigationManager = provider.GetRequiredService<NavigationManager>();
    //var backendUrl = navigationManager.BaseUri;
    //options.Address = new Uri(backendUrl);*/

    /*options.Address = new Uri("https://localhost:5101");*/

    var _config = provider.GetRequiredService<Config>();
    options.Address = new Uri(_config.Connection.EndPoints.MainServer);
}).ConfigurePrimaryHttpMessageHandler<GrpcWebHandler>();

await builder.Build().RunAsync();

/// <summary> Top Code. </summary>
public partial class Program
{
}
